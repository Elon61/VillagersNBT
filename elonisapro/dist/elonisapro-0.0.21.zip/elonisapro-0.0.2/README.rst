Gaaaaaaa
=======================

This is a useless thing that is useless in every possible way, shape or form.
----
